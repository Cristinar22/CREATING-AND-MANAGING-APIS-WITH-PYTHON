
@app.route('/posts/<int:post_id>/comments', methods=['POST'])
def add_comment(post_id):
    post = Post.query.get_or_404(post_id)
    data = request.get_json()
    new_comment = Comment(content=data['content'], post_id=post.id)
    db.session.add(new_comment)
    db.session.commit()
    return jsonify({'message': 'Comment added successfully!'}), 201
