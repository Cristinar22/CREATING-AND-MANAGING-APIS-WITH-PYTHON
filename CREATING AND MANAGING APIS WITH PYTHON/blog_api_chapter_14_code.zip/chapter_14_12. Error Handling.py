
@app.errorhandler(404)
def not_found(error):
    return jsonify({'message': 'Resource not found'}), 404
