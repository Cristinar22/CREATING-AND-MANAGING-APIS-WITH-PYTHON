
@app.route('/posts/<int:post_id>/comments', methods=['GET'])
def get_comments(post_id):
    post = Post.query.get_or_404(post_id)
    return jsonify([{'id': comment.id, 'content': comment.content} for comment in post.comments])
