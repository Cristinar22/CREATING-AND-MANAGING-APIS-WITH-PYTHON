
@app.route('/posts/search', methods=['GET'])
def search_posts():
    query = request.args.get('q', '')  # Get search query from the URL
    posts = Post.query.filter(Post.title.contains(query) | Post.content.contains(query)).all()
    return jsonify([{'id': post.id, 'title': post.title, 'content': post.content} for post in posts])
