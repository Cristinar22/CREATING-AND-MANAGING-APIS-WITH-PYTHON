# Hands-On Example: Caching for API Endpoints
from flask import Flask, jsonify, request
from flask_caching import Cache
import redis

app = Flask(__name__)

# Configuring Flask cache to use Redis
app.config['CACHE_TYPE'] = 'RedisCache'
app.config['CACHE_REDIS_URL'] = "redis://localhost:6379/0"
cache = Cache(app)

# Sample to-do data
tasks = [{"id": 1, "title": "Finish project", "done": False},
         {"id": 2, "title": "Buy groceries", "done": False}]

@app.route('/tasks', methods=['GET'])
@cache.cached(timeout=60)  # Cache this endpoint for 60 seconds
def get_tasks():
    return jsonify(tasks)

if __name__ == '__main__':
    app.run(debug=True)
    