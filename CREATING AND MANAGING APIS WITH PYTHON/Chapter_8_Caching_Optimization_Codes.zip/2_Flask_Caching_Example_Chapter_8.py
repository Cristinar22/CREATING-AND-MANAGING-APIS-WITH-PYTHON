# Integrating Redis with Flask
from flask import Flask, jsonify
from flask_caching import Cache
import redis

# Initialize Flask app
app = Flask(__name__)

# Configure Redis cache
app.config['CACHE_TYPE'] = 'RedisCache'
app.config['CACHE_REDIS_URL'] = "redis://localhost:6379/0"
cache = Cache(app)

# Example data that will be cached
data = {"message": "Hello, world!"}

@app.route('/hello', methods=['GET'])
@cache.cached(timeout=60)  # Cache this endpoint for 60 seconds
def hello():
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
    