# Setting Up Redis
# macOS: brew install redis
# Linux: sudo apt-get install redis-server
# Windows: Follow official Redis installation guide or use Docker

# Start Redis server
# redis-server
    