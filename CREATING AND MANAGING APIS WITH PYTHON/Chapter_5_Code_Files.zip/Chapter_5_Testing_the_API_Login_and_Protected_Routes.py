# Testing the Login:
# Send a POST request to /login with JSON data that includes a username and password:
# Example JSON:
# {
#     "username": "user1",
#     "password": "password123"
# }
# If login is successful, you will receive a JWT token in the response.

# Testing the Protected Route:
# Send a GET request to /protected with the JWT token in the Authorization header:
# Example:
# Authorization: Bearer YOUR_JWT_TOKEN
# If the token is valid, you will get a successful response confirming that the route is protected.