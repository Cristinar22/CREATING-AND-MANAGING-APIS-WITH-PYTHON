from flask import Flask, jsonify, request
from flask_jwt_extended import JWTManager, create_access_token, jwt_required

app = Flask(__name__)

# Set the secret key to sign the JWT tokens
app.config['SECRET_KEY'] = 'your_secret_key_here'

# Initialize the JWT manager
jwt = JWTManager(app)

# Example users
users = {
    "user1": {"password": "password123"},
    "user2": {"password": "password456"}
}

@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username', None)
    password = request.json.get('password', None)

    # Check if username and password are correct
    if username in users and users[username]['password'] == password:
        # Create a JWT token
        access_token = create_access_token(identity=username)
        return jsonify(access_token=access_token), 200
    return jsonify({"msg": "Bad username or password"}), 401

@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    return jsonify(message="This is a protected route."), 200

if __name__ == '__main__':
    app.run(debug=True)