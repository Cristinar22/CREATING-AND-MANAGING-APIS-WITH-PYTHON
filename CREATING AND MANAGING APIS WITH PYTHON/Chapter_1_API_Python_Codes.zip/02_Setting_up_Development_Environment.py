
# Command to install Flask
pip install flask

# Command to install requests library
pip install requests
