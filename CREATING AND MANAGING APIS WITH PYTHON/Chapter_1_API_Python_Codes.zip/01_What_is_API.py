
import requests

# The URL for the public API
url = "https://jsonplaceholder.typicode.com/posts"

# Send a GET request to the API
response = requests.get(url)

# Check if the request was successful
if response.status_code == 200:
    # Convert the response to JSON format
    data = response.json()
    
    # Print the first post from the data
    print("Title of first post:", data[0]['title'])
else:
    print("Failed to retrieve data", response.status_code)
