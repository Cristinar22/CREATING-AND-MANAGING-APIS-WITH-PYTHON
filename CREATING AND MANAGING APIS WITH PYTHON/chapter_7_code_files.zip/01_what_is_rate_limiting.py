
from flask import Flask, jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Initialize the limiter
limiter = Limiter(app, key_func=get_remote_address)

@app.route('/')
@limiter.limit("5 per minute")  # Allow 5 requests per minute
def index():
    return jsonify(message="Welcome to the API!")

if __name__ == '__main__':
    app.run(debug=True)
