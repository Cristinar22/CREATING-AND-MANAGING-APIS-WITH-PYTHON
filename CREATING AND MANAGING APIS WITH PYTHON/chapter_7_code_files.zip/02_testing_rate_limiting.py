
# To run your application
# Command:
# python app.py

# Test your rate limiting with Postman or Browser
# The server will respond with a 429 Too Many Requests error after 5 requests within the same minute.
