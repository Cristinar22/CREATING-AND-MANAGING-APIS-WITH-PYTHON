
from flask import Flask, jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Initialize Limiter
limiter = Limiter(app, key_func=get_remote_address)

# Sample data
tasks = []

# Rate limit: 5 requests per minute per IP
@app.route('/tasks', methods=['GET'])
@limiter.limit("5 per minute")
def get_tasks():
    return jsonify(tasks)

@app.route('/tasks', methods=['POST'])
@limiter.limit("3 per minute")
def create_task():
    data = request.get_json()
    task = {"title": data["title"], "done": False}
    tasks.append(task)
    return jsonify({"message": "Task created successfully"}), 201

if __name__ == '__main__':
    app.run(debug=True)
