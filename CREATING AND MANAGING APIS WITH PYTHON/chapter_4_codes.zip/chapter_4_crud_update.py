# Update: Modifying an Existing Task
@app.route('/tasks/<int:id>', methods=['PUT'])
def update_task(id):
    task = Task.query.get_or_404(id)  # Find the task by ID or return 404 if not found
    data = request.get_json()
    task.title = data['title']
    task.done = data['done']
    db.session.commit()  # Commit the changes to the database
    return jsonify({'message': 'Task updated successfully', 'task': {'id': task.id, 'title': task.title, 'done': task.done}})
