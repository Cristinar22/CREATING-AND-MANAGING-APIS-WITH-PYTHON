# Delete: Removing a Task
@app.route('/tasks/<int:id>', methods=['DELETE'])
def delete_task(id):
    task = Task.query.get_or_404(id)  # Find the task by ID or return 404 if not found
    db.session.delete(task)  # Delete the task
    db.session.commit()  # Commit the changes to the database
    return jsonify({'message': 'Task deleted successfully'})
