# Read: Fetching All Tasks
@app.route('/tasks', methods=['GET'])
def get_tasks():
    tasks = Task.query.all()  # Get all tasks from the database
    tasks_list = [{'id': task.id, 'title': task.title, 'done': task.done} for task in tasks]
    return jsonify(tasks_list)
