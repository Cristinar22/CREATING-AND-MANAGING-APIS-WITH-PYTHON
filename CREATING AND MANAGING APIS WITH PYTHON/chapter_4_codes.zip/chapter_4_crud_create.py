# Create: Adding a New Task
@app.route('/tasks', methods=['POST'])
def add_task():
    data = request.get_json()  # Get data from the request body
    new_task = Task(title=data['title'], done=data.get('done', False))  # Create a new task
    db.session.add(new_task)  # Add the task to the database
    db.session.commit()  # Commit the changes to the database
    return jsonify({'message': 'Task created successfully', 'task': {'id': new_task.id, 'title': new_task.title, 'done': new_task.done}}), 201
