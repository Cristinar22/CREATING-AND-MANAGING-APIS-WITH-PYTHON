from flask import Blueprint, jsonify, request

users_bp = Blueprint('users', __name__)

users = []

@users_bp.route('/register', methods=['POST'])
def register_user():
    data = request.get_json()
    username = data['username']
    password = data['password']
    users.append({'username': username, 'password': password})
    return jsonify({'message': 'User registered successfully'}), 201

@users_bp.route('/users', methods=['GET'])
def get_users():
    return jsonify(users)