from flask import Flask
from .users.routes import users_bp
from .tasks.routes import tasks_bp

def create_app():
    app = Flask(__name__)
    app.register_blueprint(users_bp, url_prefix='/users')
    app.register_blueprint(tasks_bp, url_prefix='/tasks')
    return app