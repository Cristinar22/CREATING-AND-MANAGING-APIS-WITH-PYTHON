from flask import Blueprint, jsonify, request

users_bp = Blueprint('users', __name__)

users = []

@users_bp.route('/register', methods=['POST'])
def register_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    # Basic validation
    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400
    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters long'}), 400

    users.append({'username': username, 'password': password})
    return jsonify({'message': 'User registered successfully'}), 201