from flask import Flask, jsonify, request
from flask_marshmallow import Marshmallow

app = Flask(__name__)
ma = Marshmallow(app)

# Task Schema for validation
class TaskSchema(ma.Schema):
    class Meta:
        fields = ('title', 'done')

@app.route('/tasks', methods=['POST'])
def create_task():
    # Validate input data
    task_data = request.get_json()
    schema = TaskSchema()
    errors = schema.validate(task_data)
    if errors:
        return jsonify(errors), 400

    tasks.append(task_data)
    return jsonify({"message": "Task created successfully"}), 201