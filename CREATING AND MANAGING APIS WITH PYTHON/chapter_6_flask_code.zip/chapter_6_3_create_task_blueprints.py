from flask import Blueprint, jsonify, request

tasks_bp = Blueprint('tasks', __name__)

tasks = []

@tasks_bp.route('/tasks', methods=['POST'])
def create_task():
    data = request.get_json()
    task_title = data['title']
    tasks.append({'title': task_title, 'done': False})
    return jsonify({'message': 'Task created successfully'}), 201

@tasks_bp.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks)