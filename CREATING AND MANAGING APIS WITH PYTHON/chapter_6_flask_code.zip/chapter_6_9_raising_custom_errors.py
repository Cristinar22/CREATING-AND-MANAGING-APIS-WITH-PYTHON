from flask import abort

@app.route('/tasks', methods=['POST'])
def create_task():
    data = request.get_json()
    if not data.get('title'):
        abort(400, description="Task title is required")
    tasks.append(data)
    return jsonify({"message": "Task created successfully"}), 201