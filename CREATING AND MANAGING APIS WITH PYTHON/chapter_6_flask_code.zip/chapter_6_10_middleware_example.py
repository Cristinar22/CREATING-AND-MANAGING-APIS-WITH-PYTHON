from flask import request

@app.before_request
def log_request():
    print(f"Incoming request: {request.method} {request.url}")