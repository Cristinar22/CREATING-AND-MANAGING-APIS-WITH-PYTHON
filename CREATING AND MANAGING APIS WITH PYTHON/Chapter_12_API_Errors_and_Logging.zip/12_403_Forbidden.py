
@app.route('/tasks/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_task(id):
    task = Task.query.get(id)
    if task.user_id != get_jwt_identity():  # Check if the user is the owner
        return jsonify({'message': 'Forbidden'}), 403
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'Task deleted successfully'})
