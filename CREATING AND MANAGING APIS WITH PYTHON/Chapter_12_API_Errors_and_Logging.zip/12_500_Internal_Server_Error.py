
@app.route('/tasks', methods=['POST'])
def create_task():
    try:
        data = request.get_json()
        new_task = Task(title=data['title'])
        db.session.add(new_task)
        db.session.commit()
        return jsonify({'message': 'Task created successfully'}), 201
    except Exception as e:
        app.logger.error(f"Error: {e}")
        return jsonify({'message': 'Internal server error. Please try again later.'}), 500
