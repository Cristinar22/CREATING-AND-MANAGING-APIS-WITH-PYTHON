
from flask import Flask, jsonify
import requests

app = Flask(__name__)

@app.route('/user/<int:id>', methods=['GET'])
def get_user(id):
    try:
        response = requests.get(f'https://external-api.com/user/{id}')
        if response.status_code == 200:
            return jsonify(response.json())
        else:
            raise Exception("External API failed")
    except Exception:
        return jsonify({"message": "Service temporarily unavailable. Showing cached data."}), 503
