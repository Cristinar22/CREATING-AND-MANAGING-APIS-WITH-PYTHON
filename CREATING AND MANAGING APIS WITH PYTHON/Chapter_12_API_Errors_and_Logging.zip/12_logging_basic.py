
import logging
from flask import Flask, jsonify

app = Flask(__name__)

# Set up basic logging
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

@app.route('/tasks', methods=['GET'])
def get_tasks():
    try:
        tasks = Task.query.all()
        return jsonify([task.title for task in tasks])
    except Exception as e:
        app.logger.error(f"Error: {e}")
        return jsonify({'message': 'Internal server error'}), 500
