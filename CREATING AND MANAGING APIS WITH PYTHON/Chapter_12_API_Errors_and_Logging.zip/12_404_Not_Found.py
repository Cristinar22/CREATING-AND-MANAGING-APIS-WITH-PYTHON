
@app.route('/tasks/<int:id>', methods=['GET'])
def get_task(id):
    task = Task.query.get(id)
    if not task:
        return jsonify({'message': f'Task with ID {id} not found'}), 404
    return jsonify({'id': task.id, 'title': task.title, 'done': task.done})
