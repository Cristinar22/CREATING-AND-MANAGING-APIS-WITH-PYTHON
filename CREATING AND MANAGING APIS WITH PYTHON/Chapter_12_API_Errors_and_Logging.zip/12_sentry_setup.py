
import sentry_sdk
from sentry_sdk.integrations.flask import FlaskIntegration

sentry_sdk.init(
    dsn="https://your_sentry_dsn_here",
    integrations=[FlaskIntegration()]
)
