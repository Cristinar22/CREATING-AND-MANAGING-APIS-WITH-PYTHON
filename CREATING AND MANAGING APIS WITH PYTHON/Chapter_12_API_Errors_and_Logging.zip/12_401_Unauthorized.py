
from flask_jwt_extended import jwt_required

@app.route('/tasks', methods=['GET'])
@jwt_required()
def get_tasks():
    tasks = Task.query.all()
    return jsonify([task.title for task in tasks])
