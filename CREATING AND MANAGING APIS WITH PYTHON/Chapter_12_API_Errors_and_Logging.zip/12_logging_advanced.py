
file_handler = logging.FileHandler('app.log')
console_handler = logging.StreamHandler()

logging.basicConfig(level=logging.ERROR, handlers=[file_handler, console_handler])
