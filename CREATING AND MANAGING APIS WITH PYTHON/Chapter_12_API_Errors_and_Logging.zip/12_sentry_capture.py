
@app.route('/tasks', methods=['GET'])
def get_tasks():
    try:
        tasks = Task.query.all()
        return jsonify([task.title for task in tasks])
    except Exception as e:
        sentry_sdk.capture_exception(e)
        return jsonify({'message': 'Internal server error'}), 500
