
# USING MOCKING TO SIMULATE API RESPONSES

# What is Mocking?
# Mocking is a technique used in unit testing to simulate the behavior of real objects or components. Instead of interacting with real databases, APIs, or services, you replace those components with mock objects that return predefined responses.

# Mocking is especially useful when:
# • You want to isolate the unit of code being tested from external dependencies (e.g., databases, APIs).
# • You want to simulate different scenarios that are difficult to reproduce with real systems (e.g., network failures, timeouts).

# Using unittest.mock in Pytest
# The Python standard library includes a module called unittest.mock, which allows you to replace real objects with mocks.
# Here’s an example of how to mock an external API call in Flask:

# 1. Mock an external API call:
# Suppose your Flask API calls an external service to fetch weather data. You can mock the external service’s response to test how your API behaves without making real API calls.
# Let’s say your Flask app contains the following route:

# python
import requests

@app.route('/weather', methods=['GET'])
def get_weather():
    response = requests.get('https://api.weather.com')
    return jsonify({"temperature": response.json()['temperature']})

# In this case, instead of actually calling the weather API, you can mock the requests.get() method to return a predefined response.

# 2. Write the test with mocking:

# python
from unittest.mock import patch
import pytest
from app import app

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

def test_get_weather(client):
    # Mock the requests.get method
    with patch('requests.get') as mock_get:
        mock_get.return_value.json.return_value = {'temperature': 75}
        response = client.get('/weather')
        assert response.status_code == 200
        assert b'75' in response.data

# Explanation:
# • patch: The patch() function replaces requests.get with a mock function. The mock function’s return_value is set to return a dictionary with a temperature of 75.
# • mock_get.return_value.json.return_value: This sets up the mock response’s .json() method to return the mocked data.
# • Test validation: The test checks if the temperature value 75 is correctly returned in the response.
