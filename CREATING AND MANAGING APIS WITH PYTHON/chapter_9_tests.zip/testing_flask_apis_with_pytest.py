
# TESTING FLASK APIS WITH PYTEST

# Why Use Pytest for Flask Testing?
# Pytest is one of the most popular testing frameworks in Python, and it works great with Flask. Pytest is:
# • Easy to use: It has a simple syntax that allows you to write tests quickly.
# • Powerful: It supports fixtures, assertions, and other advanced testing features.
# • Extensible: You can write custom plugins and hooks to extend its functionality.

# Setting Up Pytest with Flask
# Before you start writing tests, you need to install pytest and other necessary dependencies:

# bash
# pip install pytest pytest-flask

# • pytest: The testing framework.
# • pytest-flask: A plugin for testing Flask applications with pytest.

# Writing Your First Test
# Let’s assume we have a simple Flask application with one endpoint that returns a list of tasks:

# python
from flask import Flask, jsonify

app = Flask(__name__)

tasks = [{"id": 1, "title": "Finish project", "done": False}]

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks)

if __name__ == '__main__':
    app.run(debug=True)

# Now, let's write a test to ensure the /tasks endpoint returns the correct response.

# 1. Create a new file called test_app.py in the same directory as app.py.
# 2. Write the test using pytest:

# python
import pytest
from app import app

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

def test_get_tasks(client):
    response = client.get('/tasks')
    assert response.status_code == 200
    assert b"Finish project" in response.data

# Explanation:
# • client fixture: This fixture creates a test client that simulates making requests to the Flask app. It ensures that the Flask app is set up properly for testing.
# • test_get_tasks: This test sends a GET request to /tasks and checks if the status code is 200 (OK) and if the task title "Finish project" is present in the response data.

# 3. Run the test:
# You can run your test by simply running the following command in your terminal:
# bash
# pytest
# Pytest will discover and run all the test cases in the test_app.py file.
