
# HANDS-ON EXAMPLE: WRITE UNIT TESTS FOR THE FLASK API AND ENSURE THE FUNCTIONALITY OF VARIOUS ENDPOINTS

# Setting Up the Project
# Let’s implement unit tests for our Flask API with a variety of test cases. We’ll test the following functionality:
# 1. GET /tasks: Retrieve the list of tasks.
# 2. POST /tasks: Add a new task.
# 3. GET /tasks/<id>: Retrieve a specific task by its ID.
# 4. PUT /tasks/<id>: Update a task’s status.
# 5. DELETE /tasks/<id>: Delete a task.

# 6. Create your app.py:

# python
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tasks.db'
db = SQLAlchemy(app)

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    done = db.Column(db.Boolean, default=False)

@app.route('/tasks', methods=['GET'])
def get_tasks():
    tasks = Task.query.all()
    return jsonify([task.title for task in tasks])

@app.route('/tasks', methods=['POST'])
def add_task():
    data = request.get_json()
    new_task = Task(title=data['title'])
    db.session.add(new_task)
    db.session.commit()
    return jsonify({"message": "Task added"}), 201

@app.route('/tasks/<int:id>', methods=['GET'])
def get_task(id):
    task = Task.query.get_or_404(id)
    return jsonify({"title": task.title, "done": task.done})

@app.route('/tasks/<int:id>', methods=['PUT'])
def update_task(id):
    task = Task.query.get_or_404(id)
    data = request.get_json()
    task.done = data.get('done', task.done)
    db.session.commit()
    return jsonify({"message": "Task updated"})

@app.route('/tasks/<int:id>', methods=['DELETE'])
def delete_task(id):
    task = Task.query.get_or_404(id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({"message": "Task deleted"})

# 2. Write your unit tests in test_app.py:

# python
import pytest
from app import app, db, Task

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

@pytest.fixture
def init_db():
    db.create_all()
    task1 = Task(title="Finish project")
    task2 = Task(title="Buy groceries")
    db.session.add(task1)
    db.session.add(task2)
    db.session.commit()
    yield db
    db.drop_all()

def test_get_tasks(client, init_db):
    response = client.get('/tasks')
    assert response.status_code == 200
    assert b'Finish project' in response.data
    assert b'Buy groceries' in response.data

def test_add_task(client, init_db):
    response = client.post('/tasks', json={'title': 'Clean room'})
    assert response.status_code == 201
    assert b'Task added' in response.data

def test_get_task(client, init_db):
    task = Task.query.first()
    response = client.get(f'/tasks/{task.id}')
    assert response.status_code == 200
    assert b'Finish project' in response.data

def test_update_task(client, init_db):
    task = Task.query.first()
    response = client.put(f'/tasks/{task.id}', json={'done': True})
    assert response.status_code == 200
    task = Task.query.get(task.id)
    assert task.done is True

def test_delete_task(client, init_db):
    task = Task.query.first()
    response = client.delete(f'/tasks/{task.id}')
    assert response.status_code == 200
    task = Task.query.get(task.id)
    assert task is None
