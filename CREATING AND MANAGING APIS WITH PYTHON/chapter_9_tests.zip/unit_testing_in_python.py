
# INTRODUCTION TO UNIT TESTING IN PYTHON

# What is Unit Testing?
# Unit testing involves testing individual units or components of your code in isolation to ensure they work as expected. In the context of an API, unit tests help ensure that each part of your API—whether it's a route, a function, or a database query—behaves correctly.

# Unit tests:
# • Test small parts of your code: A unit test focuses on testing a single function or method in isolation.
# • Should be independent: Unit tests should not depend on external systems like databases or APIs, which is why mock data is often used.
# • Should be automated: Running tests automatically makes it easier to catch issues quickly.

# Benefits of Unit Testing
# • Faster feedback: You can test your code frequently and catch errors early.
# • Easier refactoring: When you make changes, running tests ensures that you don’t break existing functionality.
# • Better documentation: Unit tests serve as a form of documentation for how your code is supposed to work.

# Unit Testing Frameworks in Python
# There are several frameworks for unit testing in Python:
# • unittest: A built-in Python module that allows you to create tests.
# • pytest: A more flexible and powerful testing framework that supports fixtures, assertions, and plugins.
# • nose2: An extended version of unittest that simplifies test discovery.

# In this chapter, we will primarily use pytest because of its simplicity and additional features.
