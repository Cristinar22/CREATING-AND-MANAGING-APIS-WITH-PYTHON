
# Vertical Scaling
# Example code for scaling up an EC2 instance with AWS SDK
import boto3

def scale_up_instance(instance_id):
    ec2 = boto3.client('ec2')
    response = ec2.modify_instance_attribute(
        InstanceId=instance_id,
        InstanceType={'Value': 't2.large'}  # Example to scale up to a larger instance
    )
    return response
    