
# Caching with Redis for Flask
from flask import Flask
from flask_caching import Cache

app = Flask(__name__)

# Set up Redis caching
app.config['CACHE_TYPE'] = 'RedisCache'
app.config['CACHE_REDIS_URL'] = "redis://localhost:6379/0"
cache = Cache(app)

@app.route('/posts', methods=['GET'])
@cache.cached(timeout=60)  # Cache the response for 60 seconds
def get_posts():
    # Assuming `Post` is a model class for fetching posts
    posts = Post.query.all()
    return jsonify([{'id': post.id, 'title': post.title, 'content': post.content} for post in posts])
    