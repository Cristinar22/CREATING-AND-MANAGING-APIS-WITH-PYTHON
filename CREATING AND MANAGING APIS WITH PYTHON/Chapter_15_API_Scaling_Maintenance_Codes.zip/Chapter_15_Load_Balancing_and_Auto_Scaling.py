
# Load Balancing Setup using AWS SDK (ELB)
import boto3

def setup_load_balancer():
    elb = boto3.client('elb')
    response = elb.create_load_balancer(
        LoadBalancerName='my-load-balancer',
        Listeners=[
            {'Protocol': 'HTTP', 'LoadBalancerPort': 80, 'InstancePort': 80}
        ],
        AvailabilityZones=['us-east-1a']
    )
    return response
    