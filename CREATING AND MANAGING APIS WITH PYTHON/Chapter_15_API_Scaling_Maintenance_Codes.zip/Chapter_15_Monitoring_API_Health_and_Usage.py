
# Monitoring API with CloudWatch (logging example)
import logging
import boto3

# Set up CloudWatch logging in your Flask app
logging.basicConfig(level=logging.INFO)
app.logger.addHandler(logging.StreamHandler())

# Create CloudWatch client
cloudwatch = boto3.client('logs')

def setup_cloudwatch_logs():
    response = cloudwatch.create_log_stream(
        logGroupName='API-Logs',
        logStreamName='API-Log-Stream'
    )
    return response
    