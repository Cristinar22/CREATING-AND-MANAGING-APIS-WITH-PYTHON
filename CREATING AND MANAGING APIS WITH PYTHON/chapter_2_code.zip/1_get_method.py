
from flask import Flask, jsonify

app = Flask(__name__)

# A list of users to simulate a database
users = [
    {"id": 1, "name": "John Doe", "email": "john.doe@example.com"},
    {"id": 2, "name": "Jane Smith", "email": "jane.smith@example.com"}
]

# Route to get all users
@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users)

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
