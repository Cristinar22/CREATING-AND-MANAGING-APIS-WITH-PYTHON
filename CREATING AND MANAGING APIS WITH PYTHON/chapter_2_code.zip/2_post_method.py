
from flask import Flask, request, jsonify

app = Flask(__name__)

users = []

# Route to add a new user
@app.route('/users', methods=['POST'])
def add_user():
    new_user = request.get_json()
    users.append(new_user)
    return jsonify(new_user), 201

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
