
from flask import Flask, request, jsonify

app = Flask(__name__)

users = [{"id": 1, "name": "John Doe", "email": "john.doe@example.com"}]

# Route to update an existing user
@app.route('/users/<int:id>', methods=['PUT'])
def update_user(id):
    updated_user = request.get_json()
    for user in users:
        if user['id'] == id:
            user.update(updated_user)
            return jsonify(user)
    return jsonify({"error": "User not found"}), 404

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
