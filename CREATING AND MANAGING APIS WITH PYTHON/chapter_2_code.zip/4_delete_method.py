
from flask import Flask, request, jsonify

app = Flask(__name__)

users = [{"id": 1, "name": "John Doe", "email": "john.doe@example.com"}]

# Route to delete a user
@app.route('/users/<int:id>', methods=['DELETE'])
def delete_user(id):
    global users
    users = [user for user in users if user['id'] != id]
    return jsonify({"message": "User deleted successfully"})

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
