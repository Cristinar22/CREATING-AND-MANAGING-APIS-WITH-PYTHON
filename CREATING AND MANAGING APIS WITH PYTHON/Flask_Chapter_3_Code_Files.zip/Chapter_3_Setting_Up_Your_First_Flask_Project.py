# Setting up Your First Flask Project

# Installing Flask
pip install flask

# Creating a folder for your project
mkdir my_flask_project
cd my_flask_project

# Creating a Python file called app.py
touch app.py

# Content of app.py (the first Flask app)
from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

if __name__ == '__main__':
    app.run(debug=True)
