# Creating API Endpoints with Flask

from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample data (a list of users)
users = [
    {"id": 1, "name": "John Doe", "email": "john@example.com"},
    {"id": 2, "name": "Jane Smith", "email": "jane@example.com"}
]

# Route to get all users (GET request)
@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users)

# Route to create a new user (POST request)
@app.route('/users', methods=['POST'])
def create_user():
    new_user = request.get_json()  # Get data sent in the request body
    users.append(new_user)  # Add the new user to the list
    return jsonify(new_user), 201  # Return the new user and status code 201 (Created)

if __name__ == '__main__':
    app.run(debug=True)
