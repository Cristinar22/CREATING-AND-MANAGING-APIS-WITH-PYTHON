from flask import Flask
from bleach import clean

app = Flask(__name__)

@app.route('/profile/<name>', methods=['GET'])
def profile(name):
    safe_name = clean(name)
    return f"Welcome, {safe_name}!"
