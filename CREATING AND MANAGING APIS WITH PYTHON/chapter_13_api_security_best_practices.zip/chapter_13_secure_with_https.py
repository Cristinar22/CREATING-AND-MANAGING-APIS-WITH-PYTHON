from flask import Flask
from OpenSSL import SSL

app = Flask(__name__)

context = SSL.Context(SSL.TLSv1_2_METHOD)
context.use_privatekey_file('path/to/private.key')
context.use_certificate_file('path/to/certificate.crt')

@app.route('/')
def hello_world():
    return "Hello, HTTPS!"

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=443, ssl_context=context)
