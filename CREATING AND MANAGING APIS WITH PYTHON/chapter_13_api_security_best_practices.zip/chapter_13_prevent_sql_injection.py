from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
db = SQLAlchemy(app)

@app.route('/user/<int:id>', methods=['GET'])
def get_user(id):
    user = db.session.execute("SELECT * FROM users WHERE id = :id", {'id': id}).fetchone()
    return jsonify({'id': user.id, 'name': user.name})
