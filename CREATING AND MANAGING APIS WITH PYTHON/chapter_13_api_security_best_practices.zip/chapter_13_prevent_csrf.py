from flask import Flask, request, jsonify
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
csrf = CSRFProtect(app)

@app.route('/update_email', methods=['POST'])
def update_email():
    email = request.form['email']
    user = get_current_user()
    user.email = email
    db.session.commit()
    return jsonify({'message': 'Email updated successfully!'})
