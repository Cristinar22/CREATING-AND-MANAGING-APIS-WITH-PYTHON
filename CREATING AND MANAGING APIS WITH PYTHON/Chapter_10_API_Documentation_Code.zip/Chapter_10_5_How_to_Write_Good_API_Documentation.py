paths:
      /tasks:
        post:
          summary: Create a new task
          description: This endpoint allows users to create a new task.
          operationId: createTask
          requestBody:
            description: Task to be added
            required: true
            content:
              application/json:
                schema:
                  $ref: '#/components/schemas/Task'
          responses:
            '201':
              description: Task created successfully
              content:
                application/json:
                  schema:
                    $ref: '#/components/schemas/Task'
            '400':
              description: Bad Request
            '500':
              description: Internal Server Error
    