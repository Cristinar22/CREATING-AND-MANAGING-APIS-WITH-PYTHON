from flask_restplus import fields

    # Define the task model
    task_model = api.model('Task', {
        'id': fields.Integer(readOnly=True, description='The task unique identifier'),
        'title': fields.String(required=True, description='Task title'),
        'done': fields.Boolean(description='Task completion status')
    })

    @api.route('/tasks')
    class TaskList(Resource):
        @api.marshal_with(task_model)
        def get(self):
            """Get all tasks"""
            return tasks

        @api.expect(task_model)
        def post(self):
            """Create a new task"""
            data = api.payload
            task = {'id': len(tasks) + 1, 'title': data['title'], 'done': data.get('done', False)}
            tasks.append(task)
            return task, 201
    