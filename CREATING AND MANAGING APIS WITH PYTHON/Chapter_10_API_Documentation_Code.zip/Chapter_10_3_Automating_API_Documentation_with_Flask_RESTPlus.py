# Flask RESTPlus Code to Auto-generate Swagger Documentation

    from flask import Flask
    from flask_restplus import Api, Resource

    app = Flask(__name__)
    api = Api(app, version='1.0', title='Task API', description='A simple API for managing tasks')

    tasks = [{'id': 1, 'title': 'Finish project', 'done': False}]

    @api.route('/tasks')
    class TaskList(Resource):
        def get(self):
            """Get all tasks"""
            return tasks

        def post(self):
            """Create a new task"""
            task = {'id': len(tasks) + 1, 'title': 'New Task', 'done': False}
            tasks.append(task)
            return task, 201

    if __name__ == '__main__':
        app.run(debug=True)
    