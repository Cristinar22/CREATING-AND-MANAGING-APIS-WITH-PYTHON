openapi: 3.0.0
    info:
      title: Task API
      description: An API for managing tasks
      version: 1.0.0
    paths:
      /tasks:
        get:
          summary: Retrieves a list of tasks
          responses:
            '200':
              description: A list of tasks
              content:
                application/json:
                  schema:
                    type: array
                    items:
                      type: object
                      properties:
                        id:
                          type: integer
                        title:
                          type: string
                        done:
                          type: boolean
    